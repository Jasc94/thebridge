Propiedad intelectual de Daniel Walker y Jonathan Suarez.

Cualquier infraccióno del copyright será castigado con bullying extremo por nuestra parte.

El juego se ejecuta en main. No necesitáis saber más. Lol.

------------------------
Recomendación a la hora de revisar el código:
classes > functions > main > game
