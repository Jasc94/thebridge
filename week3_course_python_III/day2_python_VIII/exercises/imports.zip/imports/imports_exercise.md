Utilizando los archivos ".py" que están en las carpetas "a" y "b", crea dos funciones y dos variables en cada uno de los archivos. Todas las funciones han de mostrar por pantalla el nombre de la función. Los nombres de la función son 'f1x' si es la primera función del archivo 'x.py' y 'f2x' en el caso de la segunda. 

-------------------------------------------------

Una vez las tengas todas añade la siguiente funcionalidad a cada una de las funciones correspondientes:

1. La función "f1y" que has creado en el archivo 'y.py' debe llamar a la función "f1x" del archivo 'x.py'
2. La función "f2z" debe llamar a la función 'f2x'
3. La función "f1z" debe llamar a la función 'f1y'

¿ Ha dado algún error?

4. La función "f2y" debe llamar a la función 'f2x'

¿ Ha dado algún error?

5. La función "f2x" debe llamar a la función 'f2z'

¿ Ha dado algún error?

-------------------------------------------------

Al finalizar, subir a Github y enviar el enlace de vuestro repositorio de GitHub a cada uno de los profesores. Los correos de cada uno de los profesores está en el README.md y en cada archivo 'class.md'. Además, subir a classroom.