def f1x():
    return '\nf1x result\n'

def f2x():
    return '\nf2x result\n'

x1 = 'This is x1'
x2 = 'This is x2'