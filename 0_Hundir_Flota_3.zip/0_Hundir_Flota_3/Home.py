test = input('enter something')

if test == 'a':
    import Main
else:
    print('Nothing')