1) ENCONTRAR Y DESCARGAR DATASETS

El primer paso fue encontrar los datasets que se ajustaran a la temática que quería trabajar. Conseguí 3 en Kaggle con los que abarcar la hipotésis que tengo. Como siguiente paso los descargué en la correspondiente carpeta "data" dentro del proyecto.

2) PRIMER ANÁLISIS EXPLORATORIO Y DATA CLEANING
Lo primero que voy a hacer es revisar los datasets en el siguiente orden:
    1- Nutritional_values
    2- Food_production
    3- Health

Es decir, ver cuantas observaciones hay, si hay missing values, en que formato están guardados los datos, etc...