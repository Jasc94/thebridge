The units are liters (l): https://ourworldindata.org/environmental-impacts-of-food?country=#water-use

The units are squared meters (m2): https://ourworldindata.org/environmental-impacts-of-food?country=#water-use

